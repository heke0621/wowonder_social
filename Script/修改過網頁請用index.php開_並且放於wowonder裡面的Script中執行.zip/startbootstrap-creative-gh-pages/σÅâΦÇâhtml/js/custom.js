 // MDB Lightbox Init
 $(function() {
     $("#mdb-lightbox-ui").load("mdb-addons/mdb-lightbox-ui.html");
 });

 // Adding animations to the sections
 $("section").addClass("wow fadeIn");

 // Animations Init
 new WOW().init();